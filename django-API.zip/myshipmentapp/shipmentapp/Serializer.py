from rest_framework.serializers import ModelSerializer
from .models import (
    user, app_admin, country, company_address, warehouse,
    company_admin, warehouse_shipment, ci_sessions, user_consolidation, user_consolidation_purchase,
    user_payments, user_purchase, user_purchase_item
)
from varname import nameof


class userSerilizer(ModelSerializer):
    class Meta:
        model = user
        # fields = '__all__'
        fields = ["id", nameof(user.first_name),
                  nameof(user.phone_number),
                  nameof(user.date_of_birth),
                  nameof(user.address),
                  nameof(user.account_name),
                  nameof(user.account_number),
                  nameof(user.gender),
                  nameof(user.country),
                  nameof(user.province),
                  nameof(user.area),
                  nameof(user.password),
                  nameof(user.middle_name),
                  nameof(user.last_name)
                  ]


class adminSerilizer(ModelSerializer):
    class Meta:
        model = app_admin
        # fields = '__all__'
        fields = ["id", nameof(app_admin.name),
                  nameof(app_admin.email),
                  nameof(app_admin.password),
                  nameof(app_admin.phone_no),
                  nameof(app_admin.address),
                  nameof(app_admin.city),
                  nameof(app_admin.country),
                  nameof(app_admin.role)
                  ]


class countrySerilizer(ModelSerializer):
    class Meta:
        model = country
        # fields = '__all__'
        fields = ["id", nameof(country.country_name),
                  nameof(country.country_code),
                  nameof(country.country_currency)
                  ]


class company_addressSerilizer(ModelSerializer):
    class Meta:
        model = company_address
        # fields = '__all__'
        fields = ["id", nameof(company_address.name),
                  nameof(company_address.address),
                  nameof(company_address.phone_number),
                  nameof(company_address.laguage_address),
                  nameof(company_address.country_id)
                  ]


class warehouseSerilizer(ModelSerializer):
    class Meta:
        model = warehouse
        # fields = '__all__'
        fields = ["id", nameof(warehouse.name),
                  nameof(warehouse.address),
                  nameof(warehouse.phone_number),
                  nameof(warehouse.city),
                  nameof(warehouse.postal_code),
                  nameof(warehouse.country_id)
                  ]


class company_adminSerilizer(ModelSerializer):
    class Meta:
        model = company_admin
        # fields = '__all__'
        fields = ["id", nameof(company_admin.user_name),
                  nameof(company_admin.password),
                  nameof(company_admin.user_type),
                  nameof(company_admin.email),
                  nameof(company_admin.phone_number),
                  nameof(company_admin.full_name),
                  nameof(company_admin.ware_house_id)
                  ]


class warehouse_shipmentSerilizer(ModelSerializer):
    class Meta:
        model = warehouse_shipment
        # fields = '__all__'
        fields = ["id", nameof(warehouse_shipment.account_number),
                  nameof(warehouse_shipment.purchase_code),
                  nameof(warehouse_shipment.weight),
                  nameof(warehouse_shipment.amount),
                  nameof(warehouse_shipment.status),
                  nameof(warehouse_shipment.payment_type),
                  nameof(warehouse_shipment.registration_date),
                  nameof(warehouse_shipment.departure_date),
                  nameof(warehouse_shipment.arived_date),
                  nameof(warehouse_shipment.delivered_date)
                  ]


class ci_sessionsSerilizer(ModelSerializer):
    class Meta:
        model = ci_sessions
        # fields = '__all__'
        fields = ["id", nameof(ci_sessions.key_id),
                  nameof(ci_sessions.ip_address),
                  nameof(ci_sessions.timestamp),
                  nameof(ci_sessions.data)
                  ]


class user_consolidationSerilizer(ModelSerializer):
    class Meta:
        model = user_consolidation
        # fields = '__all__'
        fields = ["id", nameof(user_consolidation.code),
                  nameof(user_consolidation.status_date),
                  nameof(user_consolidation.status),
                  nameof(user_consolidation.no_of_shipment),
                  nameof(user_consolidation.actual_weight),
                  ]


class user_consolidation_purchaseSerilizer(ModelSerializer):
    class Meta:
        model = user_consolidation_purchase
        # fields = '__all__'
        fields = ["id", nameof(user_consolidation_purchase.consolidation_id),
                  nameof(user_consolidation_purchase.shipment_id),
                  ]


class user_paymentsSerilizer(ModelSerializer):
    class Meta:
        model = user_payments
        # fields = '__all__'
        fields = ["id", nameof(user_payments.user_code),
                  nameof(user_payments.shipment_id),
                  nameof(user_payments.amount_received),
                  nameof(user_payments.transection_code),
                  ]


class user_purchaseSerilizer(ModelSerializer):
    class Meta:
        model = user_purchase
        # fields = '__all__'
        fields = ["id", nameof(user_purchase.vendor),
                  nameof(user_purchase.warehouse_id),
                  nameof(user_purchase.purchase_date),
                  nameof(user_purchase.tracking_number),
                  nameof(user_purchase.delivery_date),
                  nameof(user_purchase.order_number),
                  nameof(user_purchase.account_number),
                  ]


class user_purchase_itemSerilizer(ModelSerializer):
    class Meta:
        model = user_purchase_item
        # fields = '__all__'
        fields = ["id", nameof(user_purchase_item.user_purchase_id),
                  nameof(user_purchase_item.description),
                  nameof(user_purchase_item.price),
                  nameof(user_purchase_item.total_amount),
                  nameof(user_purchase_item.quantity),
                  ]
