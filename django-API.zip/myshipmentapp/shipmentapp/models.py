from django.db import models
# from django.utils import timezone
# Create your models here.

# user database


class user(models.Model):
    account_number = models.CharField(max_length=256, null=True, default=None)
    first_name = models.CharField(max_length=256, null=True, default=None)
    middle_name = models.CharField(max_length=256, null=True, default=None)
    last_name = models.CharField(max_length=256, null=True, default=None)
    phone_number = models.CharField(max_length=256, null=True, default=None)
    date_of_birth = models.DateField(null=True, default=None)
    address = models.TextField(null=True, default=None)
    account_name = models.CharField(max_length=256, null=False)
    account_number = models.CharField(max_length=256, null=True, default=None)
    gender = models.CharField(max_length=256, null=False)
    country = models.CharField(max_length=256, null=True, default=None)
    province = models.CharField(max_length=256, null=True, default=None)
    area = models.CharField(max_length=256,  null=False)
    password = models.CharField(max_length=256,  null=False)
    middle_name = models.CharField(max_length=256, null=True, default=None)
    last_name = models.CharField(max_length=256, null=True, default=None)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)

# admin database


class app_admin(models.Model):
    name = models.CharField(max_length=256, null=True, default=None)
    email = models.CharField(max_length=256, null=True, default=None)
    password = models.CharField(max_length=256, null=False)
    phone_no = models.CharField(max_length=256, null=True, default=None)
    address = models.CharField(max_length=256, null=True, default=None)
    city = models.CharField(max_length=256, null=True, default=None)
    country = models.CharField(max_length=256, null=True, default=None)
    role = models.CharField(max_length=256, null=True, default=None)

# country database


class country(models.Model):
    country_name = models.CharField(max_length=256,  null=False)
    country_code = models.CharField(max_length=256,  null=False)
    country_currency = models.CharField(max_length=256,  null=False)

# company_address database


class company_address(models.Model):
    name = models.CharField(max_length=256,  null=False)
    address = models.TextField(null=False)
    phone_number = models.CharField(max_length=256,  null=False)
    laguage_address = models.TextField(null=False)
    country_id = models.ForeignKey(
        country, on_delete=models.CASCADE, null=False)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)


# warehouse database

class warehouse(models.Model):
    name = models.CharField(max_length=256,  null=False)
    address = models.TextField(null=False)
    country_id = models.ForeignKey(
        country, on_delete=models.CASCADE, null=False)
    city = models.CharField(max_length=256,  null=False)
    phone_number = models.CharField(max_length=256,  null=False)
    postal_code = models.IntegerField(null=False)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)

# company_admin database


class company_admin(models.Model):
    user_name = models.CharField(max_length=256,  null=False)
    password = models.CharField(max_length=256,  null=False)
    user_type = models.CharField(max_length=256,  null=False)
    email = models.CharField(max_length=256,  null=False)
    phone_number = models.CharField(max_length=256,  null=False)
    full_name = models.CharField(max_length=256,  null=False)
    ware_house_id = models.ForeignKey(
        warehouse, on_delete=models.CASCADE, null=False)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)

# warehouse_shipment database


class warehouse_shipment(models.Model):
    account_number = models.CharField(max_length=256,  null=False)
    purchase_code = models.CharField(max_length=256,  null=False)
    company_user_id = models.ForeignKey(
        company_admin, on_delete=models.CASCADE, null=False)
    weight = models.DecimalField(max_digits=10, decimal_places=3, null=False)
    amount = models.DecimalField(max_digits=10, decimal_places=3, null=False)
    status = models.SmallIntegerField(null=False)
    payment_type = models.CharField(max_length=256,  null=False)
    registration_date = models.DateTimeField(null=False, default=None)
    departure_date = models.DateTimeField(null=False, default=None)
    arived_date = models.DateTimeField(null=False, default=None)
    delivered_date = models.DateTimeField(null=False, default=None)
    destination_warehouse_id = models.ForeignKey(
        warehouse, on_delete=models.CASCADE, null=False)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)


# ci_sessions tabel


class ci_sessions(models.Model):
    key_id = models.CharField(max_length=256,  null=False)
    ip_address = models.CharField(max_length=256,  null=False)
    timestamp = models.CharField(max_length=256,  null=False)
    data = models.TextField(null=False)


# user_consolidation tabel


class user_consolidation(models.Model):
    code = models.CharField(max_length=256,  null=False)
    status_date = models.DateTimeField(null=False)
    status = models.SmallIntegerField(null=False)
    no_of_shipment = models.IntegerField(null=False)
    actual_weight = models.DecimalField(
        max_digits=10, decimal_places=3, null=False)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)


# user_consolidation_purchase tabel


class user_consolidation_purchase(models.Model):
    consolidation_id = models.ForeignKey(
        user_consolidation, on_delete=models.CASCADE, null=False)
    shipment_id = models.ForeignKey(
        warehouse_shipment, on_delete=models.CASCADE, null=False)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)


# user_payments tabel


class user_payments(models.Model):
    user_code = models.IntegerField(null=False)
    shipment_id = models.ForeignKey(
        warehouse_shipment, on_delete=models.CASCADE, null=False)
    amount_received = models.DecimalField(
        max_digits=10, decimal_places=3, null=False)
    transection_code = models.CharField(max_length=256,  null=False)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)


# user_purchase tabel


class user_purchase(models.Model):
    warehouse_id = models.ForeignKey(
        warehouse, on_delete=models.CASCADE, null=False)
    vendor = models.CharField(max_length=256,  null=False)
    tracking_number = models.CharField(max_length=256,  null=False)
    purchase_date = models.DateTimeField(null=False)
    delivery_date = models.DateTimeField(null=False)
    order_number = models.CharField(max_length=256,  null=False)
    account_number = models.CharField(max_length=256,  null=False)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)


# user_purchase_item tabel


class user_purchase_item(models.Model):
    user_purchase_id = models.ForeignKey(
        user_purchase, on_delete=models.CASCADE, null=False)
    description = models.TextField(null=False)
    price = models.DecimalField(
        max_digits=10, decimal_places=3, null=False)
    total_amount = models.DecimalField(
        max_digits=10, decimal_places=3, null=False)
    quantity = models.IntegerField(null=False, default=None)
    created_on = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.IntegerField(null=True, default=None)
    updated_on = models.DateTimeField(auto_now=True, null=True)
    updated_by = models.IntegerField(null=True, default=None)
    is_deleted = models.SmallIntegerField(null=True, default=None)
    deleted_on = models.DateTimeField(auto_now_add=True, null=True)
    deleted_by = models.IntegerField(null=True, default=None)
