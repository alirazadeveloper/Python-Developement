from rest_framework.viewsets import ModelViewSet
from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from django.http.response import JsonResponse, HttpResponse
from rest_framework.parsers import JSONParser
from .models import (
    user, app_admin, country, company_address, warehouse,
    company_admin, warehouse_shipment, ci_sessions, user_consolidation, user_consolidation_purchase, user_payments,
    user_purchase, user_purchase_item
)
from .Serializer import (
    userSerilizer, adminSerilizer, countrySerilizer, company_addressSerilizer,
    warehouseSerilizer, company_adminSerilizer, warehouse_shipmentSerilizer, ci_sessionsSerilizer, user_consolidationSerilizer,
    user_consolidation_purchaseSerilizer, user_paymentsSerilizer, user_purchaseSerilizer, user_purchase_itemSerilizer
)
# Create your views here.


"""

below here is all work of user related

all API's related to user is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def usergetbyid(request):
    if bool(request.query_params['id']):
        User = user.objects.get(id=request.query_params['id'])
        User_serializer = userSerilizer(User, many=False)
        return JsonResponse(User_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def usergetall(request):
    User = user.objects.all()
    User_serializer = userSerilizer(User, many=True)
    return JsonResponse(User_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def userupdatebyid(request):
    User_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        User = user.objects.get(id=request.query_params['id'])
        User_serializer = userSerilizer(User, data=User_data)
        if User_serializer.is_valid():
            User_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def userdeletebyid(request):
    if bool(request.query_params['id']):
        User = user.objects.get(id=request.query_params['id'])
        User.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def usersave(request):
    User_data = JSONParser().parse(request)
    User_serializer = userSerilizer(data=User_data)
    if User_serializer.is_valid():
        User_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False)


"""

below here is all work of admin related

all API's related to admin is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def admingetbyid(request):
    if bool(request.query_params['id']):
        Admin = app_admin.objects.get(id=request.query_params['id'])
        Admin_serializer = adminSerilizer(Admin, many=False)
        return JsonResponse(Admin_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def admingetall(request):
    Admin = app_admin.objects.all()
    Admin_serializer = adminSerilizer(Admin, many=True)
    return JsonResponse(Admin_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def adminupdatebyid(request):
    Admin_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        Admin = app_admin.objects.get(id=request.query_params['id'])
        Admin_serializer = adminSerilizer(Admin, data=Admin_data)
        if Admin_serializer.is_valid():
            Admin_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def admindeletebyid(request):
    if bool(request.query_params['id']):
        Admin = app_admin.objects.get(id=request.query_params['id'])
        Admin.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def adminsave(request):
    Admin_data = JSONParser().parse(request)
    Admin_serializer = adminSerilizer(data=Admin_data)
    if Admin_serializer.is_valid():
        Admin_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False)


"""

below here is all work of country related

all API's related to country is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def countrygetbyid(request):
    if bool(request.query_params['id']):
        Country = country.objects.get(id=request.query_params['id'])
        Country_serializer = countrySerilizer(Country, many=False)
        return JsonResponse(Country_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def countrygetall(request):
    Country = country.objects.all()
    Country_serializer = countrySerilizer(Country, many=True)
    return JsonResponse(Country_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def countryupdatebyid(request):
    Country_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        Country = country.objects.get(id=request.query_params['id'])
        Country_serializer = countrySerilizer(Country, data=Country_data)
        if Country_serializer.is_valid():
            Country_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def countrydeletebyid(request):
    if bool(request.query_params['id']):
        Country = country.objects.get(id=request.query_params['id'])
        Country.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def countrysave(request):
    Country_data = JSONParser().parse(request)
    Country_serializer = countrySerilizer(data=Country_data)
    if Country_serializer.is_valid():
        Country_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False)


"""

below here is all work of company_address related

all API's related to company_address is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def company_addressgetbyid(request):
    if bool(request.query_params['id']):
        Company_address = company_address.objects.get(
            id=request.query_params['id'])
        Company_address_serializer = company_addressSerilizer(
            Company_address, many=False)
        return JsonResponse(Company_address_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def company_addressgetall(request):
    Company_address = company_address.objects.all()
    Company_address_serializer = company_addressSerilizer(
        Company_address, many=True)
    return JsonResponse(Company_address_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def company_addressupdatebyid(request):
    Company_address_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        Company_address = company_address.objects.get(
            id=request.query_params['id'])
        Company_address_serializer = company_addressSerilizer(
            Company_address, data=Company_address_data)
        if Company_address_serializer.is_valid():
            Company_address_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def company_addressdeletebyid(request):
    if bool(request.query_params['id']):
        Company_address = company_address.objects.get(
            id=request.query_params['id'])
        Company_address.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def company_addresssave(request):
    Company_address_data = JSONParser().parse(request)
    Company_address_serializer = company_addressSerilizer(
        data=Company_address_data)
    if Company_address_serializer.is_valid():
        Company_address_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False)


"""

below here is all work of warehouse related

all API's related to warehouse is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def warehousegetbyid(request):
    if bool(request.query_params['id']):
        Warehouse = warehouse.objects.get(
            id=request.query_params['id'])
        Warehouse_serializer = warehouseSerilizer(
            Warehouse, many=False)
        return JsonResponse(Warehouse_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def warehousegetall(request):
    Warehouse = warehouse.objects.all()
    Warehouse_serializer = warehouseSerilizer(
        Warehouse, many=True)
    return JsonResponse(Warehouse_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def warehouseupdatebyid(request):
    Warehouse_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        Warehouse = warehouse.objects.get(
            id=request.query_params['id'])
        Warehouse_serializer = warehouseSerilizer(
            Warehouse, data=Warehouse_data)
        if Warehouse_serializer.is_valid():
            Warehouse_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def warehousedeletebyid(request):
    if bool(request.query_params['id']):
        Warehouse = warehouse.objects.get(
            id=request.query_params['id'])
        Warehouse.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def warehousesave(request):
    Warehouse_data = JSONParser().parse(request)
    Warehouse_serializer = warehouseSerilizer(
        data=Warehouse_data)
    if Warehouse_serializer.is_valid():
        Warehouse_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False)


"""

below here is all work of company_admin related

all API's related to company_admin is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def company_admingetbyid(request):
    if bool(request.query_params['id']):
        Company_admin = company_admin.objects.get(
            id=request.query_params['id'])
        Company_admin_serializer = company_adminSerilizer(
            Company_admin, many=False)
        return JsonResponse(Company_admin_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def company_admingetall(request):
    Company_admin = company_admin.objects.all()
    Company_admin_serializer = company_adminSerilizer(
        Company_admin, many=True)
    return JsonResponse(Company_admin_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def company_adminupdatebyid(request):
    Company_admin_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        Company_admin = company_admin.objects.get(
            id=request.query_params['id'])
        Company_admin_serializer = company_adminSerilizer(
            Company_admin, data=Company_admin_data)
        if Company_admin_serializer.is_valid():
            Company_admin_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def company_admindeletebyid(request):
    if bool(request.query_params['id']):
        Company_admin = company_admin.objects.get(
            id=request.query_params['id'])
        Company_admin.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def company_adminsave(request):
    Company_admin_data = JSONParser().parse(request)
    Company_admin_serializer = company_adminSerilizer(
        data=Company_admin_data)
    if Company_admin_serializer.is_valid():
        Company_admin_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False)


"""

below here is all work of warehouse_shipment related

all API's related to warehouse_shipment is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def warehouse_shipmentgetbyid(request):
    if bool(request.query_params['id']):
        Warehouse_shipment = warehouse_shipment.objects.get(
            id=request.query_params['id'])
        Warehouse_shipment_serializer = warehouse_shipmentSerilizer(
            Warehouse_shipment, many=False)
        return JsonResponse(Warehouse_shipment_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def warehouse_shipmentgetall(request):
    Warehouse_shipment = warehouse_shipment.objects.all()
    Warehouse_shipment_serializer = warehouse_shipmentSerilizer(
        Warehouse_shipment, many=True)
    return JsonResponse(Warehouse_shipment_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def warehouse_shipmentupdatebyid(request):
    Warehouse_shipment_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        Warehouse_shipment = warehouse_shipment.objects.get(
            id=request.query_params['id'])
        Warehouse_shipment_serializer = warehouse_shipmentSerilizer(
            Warehouse_shipment, data=Warehouse_shipment_data)
        if Warehouse_shipment_serializer.is_valid():
            Warehouse_shipment_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def warehouse_shipmentdeletebyid(request):
    if bool(request.query_params['id']):
        Warehouse_shipment = warehouse_shipment.objects.get(
            id=request.query_params['id'])
        Warehouse_shipment.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def warehouse_shipmentsave(request):
    Warehouse_shipment_data = JSONParser().parse(request)
    Warehouse_shipment_serializer = warehouse_shipmentSerilizer(
        data=Warehouse_shipment_data)
    if Warehouse_shipment_serializer.is_valid():
        Warehouse_shipment_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False)


"""

below here is all work of ci_sessions related

all API's related to ci_sessions is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def ci_sessionsgetbyid(request):
    if bool(request.query_params['id']):
        Ci_sessions = ci_sessions.objects.get(
            id=request.query_params['id'])
        Ci_sessions_serializer = ci_sessionsSerilizer(
            Ci_sessions, many=False)
        return JsonResponse(Ci_sessions_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def ci_sessionsgetall(request):
    Ci_sessions = ci_sessions.objects.all()
    Ci_sessions_serializer = ci_sessionsSerilizer(
        Ci_sessions, many=True)
    return JsonResponse(Ci_sessions_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def ci_sessionsupdatebyid(request):
    Ci_sessions_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        Ci_sessions = ci_sessions.objects.get(
            id=request.query_params['id'])
        Ci_sessions_serializer = ci_sessionsSerilizer(
            Ci_sessions, data=Ci_sessions_data)
        if Ci_sessions_serializer.is_valid():
            Ci_sessions_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def ci_sessionsdeletebyid(request):
    if bool(request.query_params['id']):
        Ci_sessions = ci_sessions.objects.get(
            id=request.query_params['id'])
        Ci_sessions.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def ci_sessionssave(request):
    Ci_sessions_data = JSONParser().parse(request)
    Ci_sessions_serializer = ci_sessionsSerilizer(
        data=Ci_sessions_data)
    if Ci_sessions_serializer.is_valid():
        Ci_sessions_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False, status=400)


"""

below here is all work of user_consolidation related

all API's related to user_consolidation is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def user_consolidationgetbyid(request):
    if bool(request.query_params['id']):
        User_consolidation = user_consolidation.objects.get(
            id=request.query_params['id'])
        User_consolidation_serializer = user_consolidationSerilizer(
            User_consolidation, many=False)
        return JsonResponse(User_consolidation_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def user_consolidationgetall(request):
    User_consolidation = user_consolidation.objects.all()
    User_consolidation_serializer = user_consolidationSerilizer(
        User_consolidation, many=True)
    return JsonResponse(User_consolidation_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def user_consolidationupdatebyid(request):
    User_consolidation_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        User_consolidation = user_consolidation.objects.get(
            id=request.query_params['id'])
        User_consolidation_serializer = user_consolidationSerilizer(
            User_consolidation, data=User_consolidation_data)
        if User_consolidation_serializer.is_valid():
            User_consolidation_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def user_consolidationdeletebyid(request):
    if bool(request.query_params['id']):
        User_consolidation = user_consolidation.objects.get(
            id=request.query_params['id'])
        User_consolidation.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def user_consolidationsave(request):
    User_consolidation_data = JSONParser().parse(request)
    User_consolidation_serializer = user_consolidationSerilizer(
        data=User_consolidation_data)
    if User_consolidation_serializer.is_valid():
        User_consolidation_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False, status=400)


"""

below here is all work of user_consolidation_purchase related

all API's related to user_consolidation_purchase is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def user_consolidation_purchasegetbyid(request):
    if bool(request.query_params['id']):
        User_consolidation_purchase = user_consolidation_purchase.objects.get(
            id=request.query_params['id'])
        User_consolidation_purchase_serializer = user_consolidation_purchaseSerilizer(
            User_consolidation_purchase, many=False)
        return JsonResponse(User_consolidation_purchase_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def user_consolidation_purchasegetall(request):
    User_consolidation_purchase = user_consolidation_purchase.objects.all()
    User_consolidation_purchase_serializer = user_consolidation_purchaseSerilizer(
        User_consolidation_purchase, many=True)
    return JsonResponse(User_consolidation_purchase_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def user_consolidation_purchaseupdatebyid(request):
    User_consolidation_purchase_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        User_consolidation_purchase = user_consolidation_purchase.objects.get(
            id=request.query_params['id'])
        User_consolidation_purchase_serializer = user_consolidation_purchaseSerilizer(
            User_consolidation_purchase, data=User_consolidation_purchase_data)
        if User_consolidation_purchase_serializer.is_valid():
            User_consolidation_purchase_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def user_consolidation_purchasedeletebyid(request):
    if bool(request.query_params['id']):
        User_consolidation_purchase = user_consolidation_purchase.objects.get(
            id=request.query_params['id'])
        User_consolidation_purchase.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def user_consolidation_purchasesave(request):
    User_consolidation_purchase_data = JSONParser().parse(request)
    User_consolidation_purchase_serializer = user_consolidation_purchaseSerilizer(
        data=User_consolidation_purchase_data)
    if User_consolidation_purchase_serializer.is_valid():
        User_consolidation_purchase_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False, status=400)


"""

below here is all work of user_payments related

all API's related to user_payments is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def user_paymentsgetbyid(request):
    if bool(request.query_params['id']):
        User_payments = user_payments.objects.get(
            id=request.query_params['id'])
        User_payments_serializer = user_paymentsSerilizer(
            User_payments, many=False)
        return JsonResponse(User_payments_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def user_paymentsgetall(request):
    User_payments = user_payments.objects.all()
    User_payments_serializer = user_paymentsSerilizer(
        User_payments, many=True)
    return JsonResponse(User_payments_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def user_paymentsupdatebyid(request):
    User_payments_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        User_payments = user_payments.objects.get(
            id=request.query_params['id'])
        User_payments_serializer = user_paymentsSerilizer(
            User_payments, data=User_payments_data)
        if User_payments_serializer.is_valid():
            User_payments_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def user_paymentsdeletebyid(request):
    if bool(request.query_params['id']):
        User_payments = user_payments.objects.get(
            id=request.query_params['id'])
        User_payments.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def user_paymentssave(request):
    User_payments_data = JSONParser().parse(request)
    User_payments_serializer = user_paymentsSerilizer(
        data=User_payments_data)
    if User_payments_serializer.is_valid():
        User_payments_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False, status=400)


"""

below here is all work of user_purchase related

all API's related to user_purchase is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def user_purchasegetbyid(request):
    if bool(request.query_params['id']):
        User_purchase = user_purchase.objects.get(
            id=request.query_params['id'])
        User_purchase_serializer = user_purchaseSerilizer(
            User_purchase, many=False)
        return JsonResponse(User_purchase_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def user_purchasegetall(request):
    User_purchase = user_purchase.objects.all()
    User_purchase_serializer = user_purchaseSerilizer(
        User_purchase, many=True)
    return JsonResponse(User_purchase_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def user_purchaseupdatebyid(request):
    User_purchase_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        User_purchase = user_purchase.objects.get(
            id=request.query_params['id'])
        User_purchase_serializer = user_purchaseSerilizer(
            User_purchase, data=User_purchase_data)
        if User_purchase_serializer.is_valid():
            User_purchase_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def user_purchasedeletebyid(request):
    if bool(request.query_params['id']):
        User_purchase = user_purchase.objects.get(
            id=request.query_params['id'])
        User_purchase.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def user_purchasesave(request):
    User_purchase_data = JSONParser().parse(request)
    User_purchase_serializer = user_purchaseSerilizer(
        data=User_purchase_data)
    if User_purchase_serializer.is_valid():
        User_purchase_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False, status=400)


"""

below here is all work of user_purchase_item related

all API's related to user_purchase_item is defined below here

"""


@api_view(['GET'])
@permission_classes([AllowAny])
def user_purchase_itemgetbyid(request):
    if bool(request.query_params['id']):
        User_purchase_item = user_purchase_item.objects.get(
            id=request.query_params['id'])
        User_purchase_item_serializer = user_purchase_itemSerilizer(
            User_purchase_item, many=False)
        return JsonResponse(User_purchase_item_serializer.data, safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['GET'])
@permission_classes([AllowAny])
def user_purchase_itemgetall(request):
    User_purchase_item = user_purchase_item.objects.all()
    User_purchase_item_serializer = user_purchase_itemSerilizer(
        User_purchase_item, many=True)
    return JsonResponse(User_purchase_item_serializer.data, safe=False)


@api_view(['PUT'])
@permission_classes([AllowAny])
def user_purchase_itemupdatebyid(request):
    User_purchase_item_data = JSONParser().parse(request)
    if bool(request.query_params['id']):
        User_purchase_item = user_purchase_item.objects.get(
            id=request.query_params['id'])
        User_purchase_item_serializer = user_purchase_itemSerilizer(
            User_purchase_item, data=User_purchase_item_data)
        if User_purchase_item_serializer.is_valid():
            User_purchase_item_serializer.save()
            return JsonResponse("Updated Successfully!", safe=False)
        return JsonResponse("Failed to update", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['DELETE'])
@permission_classes([AllowAny])
def user_purchase_itemdeletebyid(request):
    if bool(request.query_params['id']):
        User_purchase_item = user_purchase_item.objects.get(
            id=request.query_params['id'])
        User_purchase_item.delete()
        return JsonResponse("Delete successfully", safe=False)
    else:
        return JsonResponse("id is required", safe=False)


@api_view(['POST'])
@permission_classes([AllowAny])
def user_purchase_itemsave(request):
    User_purchase_item_data = JSONParser().parse(request)
    User_purchase_item_serializer = user_purchase_itemSerilizer(
        data=User_purchase_item_data)
    if User_purchase_item_serializer.is_valid():
        User_purchase_item_serializer.save()
        return JsonResponse("Added Successfully!", safe=False)
    return JsonResponse("Failed to add", safe=False, status=400)
